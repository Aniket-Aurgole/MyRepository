package com.jbk.MVC.Project.Student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcProjectStudentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcProjectStudentApplication.class, args);
	}

}
