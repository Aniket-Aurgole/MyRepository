package com.jbk.MVC.Project.Student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcProjectStudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
